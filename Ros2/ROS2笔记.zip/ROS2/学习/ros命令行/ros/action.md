```linux
ros2 action
 info
 list
 send_goal 动作名称 动作数据类型 动作数据结构      发送一个动作
                                           --feedback   获得反馈
 type                                          获得动作的数据类型
```
