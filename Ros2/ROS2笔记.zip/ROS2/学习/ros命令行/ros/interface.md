```linux
ros2 interface
 list          显示所有可用的接口(包括srv, action , msg)
 package       显示某功能包提供的可用的接口
 packages      显示某功能包提供的所有接口
 proto         显示一个接口的原型
 show          显示一个接口的定义
```

