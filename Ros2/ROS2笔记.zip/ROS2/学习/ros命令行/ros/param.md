```linux
ros2 param
 list                    列出所有参数
 delete                  删除指定参数
 describe                描述一个参数
          节点名 参数名
 load                    为节点载入一个yaml参数文件
 set                     设置参数
 get                     得到参数的值
 dump                    将这个节点的参数复制到yaml文件
      >>路径    保存yaml到路径
 ```