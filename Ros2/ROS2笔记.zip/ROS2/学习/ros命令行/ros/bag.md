```linux
ros2 bag
 record       录制当前数据
 play           复现数据
```