```linux
ros2 node
 -h
 --help
 info       //查询节点信息
 list         //显示节点
 call        
```


