map坐标系 : 地图坐标系
odom坐标系 : 里程坐标系
base_link : 机器人基坐标系
laser_link : 雷达坐标系

### 安装TF工具包
```linux
sudo apt install ros-jazzy-tf2-tools     #安装tf2
sudo pip3 install transforms3d           #安装3d坐标变换的python库
```

### 坐标系
translation 平移变化
rotation 旋转变化

`ros2 run tf2_tools view_frames`  
订阅5秒内所有ros2的坐标系并将其关系绘制到pdf中 
`ros2 run tf2_ros tf2_echo 坐标系1 坐标系2`
展示两个坐标系之间的数值变换
`ros`