### Gazebo的安装与启动
```linux
sudo apt install ros-humble-gazebo-*
ros2 launch gazebo_ros gazebo.launch.py
```
离线模型文件库要下载并放置到`~/.gazebo/models`路径下