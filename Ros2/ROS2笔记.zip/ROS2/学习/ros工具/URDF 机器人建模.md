硬件系统、驱动系统、传感系统、控制系统

### URDF的定义
- 统一机器人描述格式 (Unified Robot Description Format)
- 可以解析URDF文件中使用XML格式描述的机器人模型
- 包含连杆 (Link)和关节 (Joint)自身及相关属性的描述信息
- 
---

### URDF常用标签
##### link
- 描述机器人某个刚体部分的外观和物理属性
- 连杆尺寸(size)、颜色(color)、形状(shape)、惯性矩阵(inertial matrix)、碰撞参数(collision properties)等
- 每个link都会成为一个坐标系
#### joint
- 描述两个link之间的关系
- 包括关节运动的位置和速度限制
- 描述机器人关节的运动学和动力学属性

| joint类型    | 描述                     |
| ---------- | ---------------------- |
| continuous | 旋转关节，可以绕单轴无限旋转         |
| revolute   | 有旋转角度极限的旋转关节           |
| prismatic  | 滑动关节，沿某一轴线移动的关节，带有位置极限 |
| fixed      | 固定关节，不允许运动的特殊关节        |
| floating   | 浮动关节，允许进行平移、旋转运动       |
| planar     | 平面关节，允许在平面正交方向上平移或者旋转  |

##### robot
- 完整机器人模型的最顶层标签
- link和joint必须包在robot标签内
- 一个完整的机器人模型由一系列link和joint组成 

---

### URDF建模过程
- urdf：存放机器人模型的URDF或xacro文件
- meshes：放置URDF中引I用的模型渲染文件
- launch：保存相关启动文件
- rviz：保存rviz的配置文件