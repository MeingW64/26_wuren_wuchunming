节点是每个机器人的基本组成单位(细胞)

### 节点的作用 :
- 执行具体任务的进程
- 节点是独立运行的可执行文件
- 可使用不同的编程语言
- 可分布式运行在不同的主机(也可以在云端)，不同的主机上可以运行不同的节点
- 按照节点名称进行管理

### 节点的编码流程 ： 
1. 编程接口初始化
2. 创建节点并初始化
3. 实现节点功能
4. 销毁节点并关闭接口
```python
import rclpy                                     # ROS2 Python接口库
from rclpy.node import Node                      # ROS2 节点类
import time

#创建一个HelloWorld节点, 初始化时输出“hello world”日志.我们自己的节点要继承父类的ros2节点
class HelloWorldNode(Node):
    def __init__(self, name):
        super().__init__(name)                       # ROS2节点父类初始化
        while rclpy.ok():                            # ROS2系统是否正常运行
            self.get_logger().info("Hello World")    # ROS2日志输出
            time.sleep(0.5)                          # 休眠控制循环时间

def main(args=None):                                 # ROS2节点主入口main函数

    rclpy.init(args=args)                            # ROS2 Python接口初始化
    node = HelloWorldNode("node_helloworld_class")   # 创建ROS2节点对象并进行初始化
    
    node.destroy_node()                              # 销毁节点对象
    rclpy.shutdown()                                 # 关闭ROS2 Python接口

```

```c++
class HelloWorldNode : public rclcpp::Node
{
    public:
        HelloWorldNode(): Node("node_helloworld_class")       // ROS2节点父类初始化
        {
            while(rclcpp::ok())                               // ROS2系统是否正常运行
            {
                RCLCPP_INFO(this->get_logger(), "Hello World");  // ROS2日志输出
                sleep(1);                                        // 休眠控制循环时间
            }
        }
};

// ROS2节点主入口main函数
int main(int argc, char * argv[])                               
{
	rclcpp::init(argc, argv);  // ROS2 C++接口初始化      

    rclcpp::spin(std::make_shared<HelloWorldNode>()); // 创建ROS2节点对象并进行初始化 
    
    rclcpp::shutdown();           // 关闭ROS2 C++接口                    
    return 0;
}

```