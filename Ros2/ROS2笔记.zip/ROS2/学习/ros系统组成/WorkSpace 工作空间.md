Ros工作空间结构 : 
- src        代码空间
- install   安装空间
- build    编译空间
- log       日志空间

配置工作空间(自动安装依赖)
在`根目录/src`目录下运行
```linux
sudo pip install python3-pip
sudo pip install rosdepc --break-system-packages
sudo rosdepc init
rpsdepc update
rosdepc install -i --from-path src --rosdistro jazzy

sudo apt install python3-colcon-ros
```

编译工作空间
在工作空间的`根目录`下运行 :
```linux
colcon build
```


配置工作空间环境变量
在`根目录/install`目录下运行
```linux
source local_setup.sh
source setup 
```

或者将这两行命令添加到bashrc文件的最后两行
`.bashrc`是linux系统用来储存并加载终端配置与环境变量的文件.为了加载你的配置，bash 在每次启动时都会加载 `.bashrc` 文件的内容


创建功能包
在`根目录/src`目录下运行
```
ros2 pkg create --build-type <build-type> <package_name>
<build-type>:不同语言的编译过程不同，因此要区分

//示例
ros2 pkg create --build-type ament_cmake learning_pkg_c
ros2 pkg create --build-type ament_python learning_pkg_python

```

python功能包中有`setup.py`文件，里面要配置程序的入口
```python
entry_points = {
	'node_helloworld_class' = learning_node.node_helloworld_class : main'
	#节点程序在 路径 的main函数中
}
```

