就是通信协议。数据传输的标准结构
通信接口可以跨语言生成对应的数据类型

话题 ：`.msg文件`
```python
# 通信数据
int32 x
int32 y
```

服务 ：`.srv文件
```python
# 请求数据
int64 a
int64 b
---
# 应答数据
int64 sum
```
`
动作 ：`.action文件`
```python
# 目标
bool enable
---
# 结果
bool isFinished
---
# 反馈
int32 state
```

