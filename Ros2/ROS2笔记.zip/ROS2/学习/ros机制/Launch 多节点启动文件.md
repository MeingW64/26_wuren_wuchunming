- 用于实现多节点的配置与启动
- 使用python语法
- 可以对节点中的资源重映射

```python
#核心代码
return LaunchDescription([
	Node(
		package = '功能包名',
		excutable = '可执行文件名',
		name = '节点名'   #可以对节点重命名
		argument = ['-d , .._config']    #配置启动项
		namespace = '命名空间名'
		remapping = []   #对节点的重映射
		parameters = [{
			参数  = LaunchConfiguration('参数名'),
		}]
	),
	Node(
		package = '功能包名',
		excutable = '可执行文件名',
	),
])
```
